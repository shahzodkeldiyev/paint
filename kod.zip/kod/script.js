let input = document.querySelector('input');
let add = document.querySelector('.add');

let typingList;
input.addEventListener('input', typing)

function typing(e) {
    typingList = e.target.value;
    if (e.value != '') {
        add.disabled = false
        add.style.transform = 'scale(1)'
    }
}

add.addEventListener('click', listAdd)

function listAdd() {

    document.querySelector('.cards').innerHTML += `
    <div class="card" data-name="${typingList}">
    <div class="p"><p>${typingList}</p></div>
    <div class="list-controls">
    <button class="delete"><i class="fa fa-window-close"></i></button>
    </div>
    </div>
    `
    input.value = ''
    typingList = 'New list'
    add.disabled = true
    add.style.transform = 'scale(0.9)'
}


setInterval(() => {
    let listDelete = document.querySelectorAll('.delete');

    for (let i = 0; i < listDelete.length; i++) {
        let listDeleteEl = listDelete[i];

        listDeleteEl.addEventListener('click', () => {
            listDeleteEl.closest('.card').remove()
        })

    }
}, 10);




// setInterval(() => {

//     let listEdit = document.querySelectorAll('.list-edit');

//     for (let i = 0; i < listEdit.length; i++) {
//         let listEditEl = listEdit[i];

//         listEditEl.addEventListener('click', () => {
//             let listName = listEditEl.closest('.card').getAttribute('data-name')
//             listEditEl.closest('.card').querySelector('.p').innerHTML = `<input type="text" class="edit-input" value="${listName}"> <button class="list-check"><i class="fas fa-check"></i></button>`
//             // listEditEl.closest('.card').querySelector('.list-edit').style.display = 'none';

//         })

//     }


// }, 10);


// setInterval(() => {


//     let listCheck = document.querySelectorAll('.list-check');
//     let editInput = document.querySelectorAll('.edit-input');
//     let editInputValue;



//     for (let i = 0; i < editInput.length; i++) {
//         const editInputEl = editInput[i];

//         editInputEl.addEventListener('input', (e) => {
//             editInputValue = e.target.value;
//         })

//     }
//     for (let i = 0; i < listCheck.length; i++) {
//         const listCheckEl = listCheck[i];

//         listCheckEl.addEventListener('click', () => {
//             // listCheckEl.style.display = 'none'
//             // listCheckEl.closest('.card').querySelector('.list-edit').style.display = 'block';
//             listCheckEl.closest('.card').querySelector('.p').innerHTML = `<p>${editInputValue}</p>`;
//         })

//     }


// }, 10);